import os
import cv2
import time
import csv
from ultralytics import YOLO

def run_inference(input_path, step_number, output_path, classes, model_path, input_type):
    os.makedirs(output_path, exist_ok=True)

    model = YOLO(model_path)

    csv_path = os.path.join(output_path, f"{step_number}_results.csv")
    video_path = os.path.join(output_path, f"{step_number}_output.mp4")
    frame_count = 0
    inference_times = []
    csv_data = []

    if input_type == "video":
        cap = cv2.VideoCapture(input_path)
        fourcc = cv2.VideoWriter_fourcc(*'avc1')
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        out = cv2.VideoWriter(video_path, fourcc, fps, (width, height))

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            start = time.time()
            results = model.predict(frame, classes=classes)
            end = time.time()

            annotated = results[0].plot()
            out.write(annotated)
            inference_times.append(end - start)

            # Collect detections
            detections = results[0].boxes
            object_names = []
            object_classes = []
            if detections is not None:
                for box in detections:
                    cls_id = int(box.cls[0]) if hasattr(box.cls, '__iter__') else int(box.cls)
                    object_names.append(model.names[cls_id])
                    object_classes.append(cls_id)

            csv_data.append({
                "Frame No": frame_count,
                "Object Name and Class": "; ".join([f"{name} ({cls})" for name, cls in zip(object_names, object_classes)]),
                "Object Count": len(object_names)
            })

            frame_count += 1

        cap.release()
        out.release()

    elif input_type == "image":
        img = cv2.imread(input_path)
        start = time.time()
        results = model.predict(img, classes=classes)
        end = time.time()
        inference_times.append(end - start)

        # Save annotated image in frames folder
        frame_dir = os.path.join(output_path, "frames")
        os.makedirs(frame_dir, exist_ok=True)

        annotated_path = os.path.join(frame_dir, f"{step_number}_annotated.jpg")
        annotated = results[0].plot()
        cv2.imwrite(annotated_path, annotated)

        detections = results[0].boxes
        object_names = []
        object_classes = []
        if detections is not None:
            for box in detections:
                cls_id = int(box.cls[0]) if hasattr(box.cls, '__iter__') else int(box.cls)
                object_names.append(model.names[cls_id])
                object_classes.append(cls_id)

        csv_data.append({
            "Frame No": 0,
            "Object Name and Class": "; ".join([f"{name} ({cls})" for name, cls in zip(object_names, object_classes)]),
            "Object Count": len(object_names)
        })

        video_path = None  # not used in image mode


    else:
        raise ValueError(f"Unsupported input_type: {input_type}")

    # Save CSV
    with open(csv_path, mode='w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=["Frame No", "Object Name and Class", "Object Count"])
        writer.writeheader()
        writer.writerows(csv_data)

    return {
        "output_path": output_path,
        "csv_file": csv_path,
        "video_file": video_path,
        "image_folder": frame_dir if input_type == "image" else None,
        "output_type": input_type
    }
